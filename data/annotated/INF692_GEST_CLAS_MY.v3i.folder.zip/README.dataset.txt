# INF692_GEST_CLAS_MY > 2025-06-20 12:25am
https://universe.roboflow.com/sibigrapi2025c/inf692_gest_clas_my

Provided by a Roboflow user
License: CC BY 4.0

