# INF692_GEST_POSE_GE > 2025-06-19 11:59pm
https://universe.roboflow.com/sibigrapi2025c/inf692_gest_pose_ge

Provided by a Roboflow user
License: CC BY 4.0

