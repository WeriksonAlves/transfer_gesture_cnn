# inf692_my_gest_pose > 2025-05-29 5:30pm
https://universe.roboflow.com/sibigrapi2025c/inf692_my_gest_pose

Provided by a Roboflow user
License: CC BY 4.0

