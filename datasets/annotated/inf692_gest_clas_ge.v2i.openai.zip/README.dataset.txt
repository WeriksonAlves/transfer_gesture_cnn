# INF692_GEST_CLAS_GE > 2025-05-31 1:29am
https://universe.roboflow.com/sibigrapi2025c/inf692_gest_clas_ge

Provided by a Roboflow user
License: CC BY 4.0

